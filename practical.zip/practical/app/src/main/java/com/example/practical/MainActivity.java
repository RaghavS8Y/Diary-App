package com.example.practical;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;



public class MainActivity extends AppCompatActivity {

    private LinearLayout layoutOccasions;
    private SharedPreferences sharedPreferences;
    private static final String SHARED_PREF_NAME = "MyDiary";
    private static final String KEY_OCCASIONS = "occasions";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DatePicker datePicker = findViewById(R.id.date_picker);
        EditText editTextOccasion = findViewById(R.id.edit_text_occasion);
        layoutOccasions = findViewById(R.id.layout_occasions);
        Button btnSave = findViewById(R.id.btn_save);

        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);


        Button clearButton = findViewById(R.id.btn_clear);
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.clear();
                editor.apply();
                updateOccasionsList(); // Update the UI to reflect the cleared list
            }
        });








        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int day = datePicker.getDayOfMonth();
                int month = datePicker.getMonth() + 1;
                int year = datePicker.getYear();
                String date = day + "/" + month + "/" + year;
                String occasion = editTextOccasion.getText().toString(); // Corrected here
                if (!date.isEmpty() && !occasion.isEmpty()) {
                    saveOccasion(date, occasion);
                    updateOccasionsList();
                    editTextOccasion.setText(""); // Clear the EditText after saving
                }
            }
        });

        updateOccasionsList();
    }



    private void saveOccasion(String date, String occasion) {
        String allOccasions = sharedPreferences.getString(KEY_OCCASIONS, "");
        allOccasions += date + ": " + occasion + "\n";
        sharedPreferences.edit().putString(KEY_OCCASIONS, allOccasions).apply();
    }

    private void updateOccasionsList() {
        String allOccasions = sharedPreferences.getString(KEY_OCCASIONS, "");
        layoutOccasions.removeAllViews();
        TextView textView = new TextView(this);
        textView.setText(allOccasions);
        layoutOccasions.addView(textView);
    }
}
